from __future__ import print_function
import numpy as np
import matplotlib
matplotlib.use('TKAgg')
import matplotlib.pyplot as plt
 
# Load the data set
data = np.loadtxt('polynome.data')
X = data[:, 0]
Y = data[:, 1]
N = len(X)

def visualize(w):
    # Plot the data
    plt.plot(X, Y, 'r.')
    # Plot the fitted curve 
    x = np.linspace(0., 1., 100)
    y = np.polyval(w, x)
    plt.plot(x, y, 'g-')
    plt.title('Polynomial regression with order ' + str(len(w)-1))
    plt.axis([-0.1, 1.1, -0.1, 1.1])
    plt.show()


# Perform the naive selection method
print('Naive method')
for deg in range(1, 11):
    w = np.polyfit(X, Y, deg)
    Y_fit = np.polyval(w, X)
    error = 0.5 * np.dot( (Y-Y_fit).T, (Y-Y_fit) ) 
    print('Polynome of order', deg, 'Training error:', error)
    visualize(w)
    

# Simple cross validation
# Split the data set
limit = int(0.7*N)
X_train, X_test = np.hsplit(X, [limit])
Y_train, Y_test = np.hsplit(Y, [limit])
print('Simple cross validation')
for deg in range(1, 11):
    w = np.polyfit(X_train, Y_train, deg)
    Y_fit_train = np.polyval(w, X_train)
    Y_fit_test = np.polyval(w, X_test)
    train_error = 0.5 * np.dot((Y_train-Y_fit_train).T, (Y_train-Y_fit_train))
    test_error = 0.5 * np.dot((Y_test-Y_fit_test).T, (Y_test-Y_fit_test))
    print('Polynome of order', deg, 'Training error:', train_error, 'Test error', test_error)

# k-fold cross validation
print('k-fold cross validation')
k = 1
nb_split = int(N/k)
X_sets = np.hsplit(X, nb_split)
Y_sets = np.hsplit(Y, nb_split)
for deg in range(1, 11):
    train_error = 0.0
    test_error = 0.0
    for s in range(nb_split):
        X_train = np.hstack((X_sets[i] for i in range(nb_split) if not i == s))
        Y_train = np.hstack((Y_sets[i] for i in range(nb_split) if not i == s))
        w = np.polyfit(X_train, Y_train, deg)
        Y_fit_train = np.polyval(w, X_train)
        Y_fit_test = np.polyval(w, X_sets[s])
        train_error += 0.5 * np.dot((Y_train-Y_fit_train).T, (Y_train-Y_fit_train))/float(nb_split)
        test_error += 0.5 * np.dot((Y_sets[s]-Y_fit_test).T, (Y_sets[s]-Y_fit_test))/float(nb_split)
    print('Polynome of order', deg, 'Training error:', train_error, 'Test error', test_error)


