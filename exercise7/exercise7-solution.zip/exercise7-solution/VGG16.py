from __future__ import print_function
import cv2
import numpy as np
import matplotlib
matplotlib.use('TKAgg')
import matplotlib.pyplot as plt

from keras.applications.vgg16 import VGG16
from keras import backend as K

def VGG_16():
    model = Sequential()
    model.add(ZeroPadding2D((1,1),input_shape=(3,224,224)))
    model.add(Convolution2D(64, 3, 3, activation='relu'))
    model.add(ZeroPadding2D((1,1)))
    model.add(Convolution2D(64, 3, 3, activation='relu'))
    model.add(MaxPooling2D((2,2), strides=(2,2)))

    model.add(ZeroPadding2D((1,1)))
    model.add(Convolution2D(128, 3, 3, activation='relu'))
    model.add(ZeroPadding2D((1,1)))
    model.add(Convolution2D(128, 3, 3, activation='relu'))
    model.add(MaxPooling2D((2,2), strides=(2,2)))

    model.add(ZeroPadding2D((1,1)))
    model.add(Convolution2D(256, 3, 3, activation='relu'))
    model.add(ZeroPadding2D((1,1)))
    model.add(Convolution2D(256, 3, 3, activation='relu'))
    model.add(ZeroPadding2D((1,1)))
    model.add(Convolution2D(256, 3, 3, activation='relu'))
    model.add(MaxPooling2D((2,2), strides=(2,2)))

    model.add(ZeroPadding2D((1,1)))
    model.add(Convolution2D(512, 3, 3, activation='relu'))
    model.add(ZeroPadding2D((1,1)))
    model.add(Convolution2D(512, 3, 3, activation='relu'))
    model.add(ZeroPadding2D((1,1)))
    model.add(Convolution2D(512, 3, 3, activation='relu'))
    model.add(MaxPooling2D((2,2), strides=(2,2)))

    model.add(ZeroPadding2D((1,1)))
    model.add(Convolution2D(512, 3, 3, activation='relu'))
    model.add(ZeroPadding2D((1,1)))
    model.add(Convolution2D(512, 3, 3, activation='relu'))
    model.add(ZeroPadding2D((1,1)))
    model.add(Convolution2D(512, 3, 3, activation='relu'))
    model.add(MaxPooling2D((2,2), strides=(2,2)))

    model.add(Flatten())
    model.add(Dense(4096, activation='relu'))
    model.add(Dropout(0.5))
    model.add(Dense(4096, activation='relu'))
    model.add(Dropout(0.5))
    model.add(Dense(1000, activation='softmax'))

    return model

def get_label(ind):
    if ind < 0 or ind > 999:
        return "Unknown"
    with open('imagenet-labels.txt', 'r') as f:
        data = f.read().split('\n')
    return data[ind] 

def resize_image(img):
    # Resize the image
    img = cv2.resize(img, (224, 224))

    # Remove the mean ImageNet image
    mean_pixel = [103.939, 116.779, 123.68]
    img = img.astype(np.float32, copy=False)
    for c in range(3):
        img[:, :, c] = img[:, :, c] - mean_pixel[c]

    # Reorder the color channels
    img = img.transpose((2,0,1))
    img = np.expand_dims(img, axis=0)

    return img

###############################
### Single image
###############################
# Load the cat image and resize it
img = cv2.imread('cat.jpg')
img = resize_image(img)

# Create the VGG16 network
print('Creating the VGG16 network...')
model = VGG16(weights='imagenet', include_top=True)

# Make a prediction
import time
print('Predicting...')
tstart = time.time()
output = model.predict(img)
print('Done in', time.time() - tstart, 'seconds.')

plt.plot(output[0])
plt.show()

# Get the top-5 prediction
top5 = (-output[0]).argsort()[:5]
for label in top5:
    print('Label:', get_label(label), '; probability:', output[0][label])


###############################
### Multiple images
###############################
# Method to access activity in the last hidden layer
get_features = K.function([model.layers[0].input, K.learning_phase()], [model.layers[-3].output])

# Load the Tapir and get the prediction
img = cv2.imread('tapir.jpg')
img = resize_image(img)
output = model.predict(img)
tapir = get_features([img.reshape(1, 3,224,224), 0])[0]
print('Prediction for the Tapir')
top5 = (-output[0]).argsort()[:5]
for label in top5:
    print('Label:', get_label(label), '; probability:', output[0][label])

# Load the Wild pig and get the prediction
img = cv2.imread('wildpig.jpg')
img = resize_image(img)
output = model.predict(img)
wildpig = get_features([img.reshape(1, 3,224,224), 0])[0]
print('Prediction for the Wild Pig')
top5 = (-output[0]).argsort()[:5]
for label in top5:
    print('Label:', get_label(label), '; probability:', output[0][label])

# Load the Test image and get the prediction
img = cv2.imread('test.jpg')
img = resize_image(img)
output = model.predict(img)
test = get_features([img.reshape(1, 3,224,224), 0])[0]
print('Prediction for the Test image')
top5 = (-output[0]).argsort()[:5]
for label in top5:
    print('Label:', get_label(label), '; probability:', output[0][label])

# Find the animal which is closer to the test image in the feature space. 
print('Euclidian distance between test and tapir', np.linalg.norm(test-tapir))
print('Euclidian distance between test and wild pig', np.linalg.norm(test-wildpig))
