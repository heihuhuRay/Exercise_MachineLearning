from __future__ import print_function

#################################
### Definition of the parameters
#################################

# Transition probabilities
alpha = 0.3
beta = 0.2

# Discount parameter
gamma = 0.7

# Expected rewards
R_search = 6.0
R_wait = 2.0

#################################
### Value iteration
#################################

# Initial values for the state-value functions
V_high = 0.0
V_low = 0.0

# Value iteration algorithm
variation = 1.0
nb_iterations = 1
while variation > 0.0001:
    # Estimating the Q* values in the high state
    Q_high_search = alpha * (R_search + gamma * V_high ) + (1- alpha)*(R_search + gamma * V_low)
    Q_high_wait = R_wait + gamma* V_high
      
    # Estimating the Q* values in the low state
    Q_low_search = beta * (R_search + gamma * V_low ) + (1- beta)*(-3. + gamma * V_high)
    Q_low_wait = R_wait + gamma * V_low
    Q_low_recharge = 0.0 + gamma * V_high
    
    # Updating the V* values by choosing the greedy action in each state
    old_V_high = V_high
    old_V_low = V_low
    V_high = max(Q_high_search, Q_high_wait)
    V_low = max(Q_low_search, Q_low_wait, Q_low_recharge)
    
    print('-'*60)
    print('Iteration', nb_iterations)
    print('Q*(high, search) = ', Q_high_search)
    print('Q*(high, wait) = ', Q_high_wait)
    print('Q*(low, search) = ', Q_low_search)
    print('Q*(low, wait) = ', Q_low_wait)
    print('Q*(low, recharge) = ', Q_low_recharge)
    print('V*(high) = max(', Q_high_search, ',', Q_high_wait, ') = ', V_high)
    print('V*(low) = max(', Q_low_search, ',', Q_low_wait, ',', Q_low_recharge, ') = ', V_low)
    
    # Convergence criterium
    variation = max(abs(V_high-old_V_high)/V_high, abs(V_low - old_V_low)/V_low)
    nb_iterations += 1
    

